    <?php
	
	$sql = "SELECT material_id, material_name FROM material";
	$result = mysql_query($sql);
	echo '<select name="materialtype" id="main_select">';
	echo '<option selected="selected">Please select materialtype</option>';
	
	while($row = mysql_fetch_array($result))
	{
		
    	echo '<option values=' . $row["material_id"] . '>' . $row["material_name"] . '</option>';

	}
	echo '</select>';
	
	
	?>

    </td>
    <td>Cloth Type</td>
    <td>
    <?php
	$parent_cat = $_GET['materialtype'];
	
	$Mysql = "SELECT cloth_id, cloth_name,cloth_material_id FROM cloth WHERE material_id=" . $parent_cat;
	$Data = mysql_query($Mysql);
	
	echo '<select name="clothtype" id="select_2">';
	echo '<option selected="selected">Please select Cloth Type</option>';
	
	while($rs = mysql_fetch_array($Data))
	{
		
    	echo '<option values=' . $rs["cloth_id"] . '>' . $rs["cloth_name"] . $rs["cloth_material_id"] . '</option>';

	}
	echo '</select>';
	
	?>
