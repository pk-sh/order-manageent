<!DOCTYPE html>
<html>
<head>
	<title>Market Management</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
function myFunction1() {
  var checkBox1 = document.getElementById("myCheck1");
  var text = document.getElementById("hidden_fields");
  if (checkBox1.checked == true){
    text.style.display = "block";
    $("#myCheck2").prop('checked',false).checkboxradio("refresh");
    $("#myCheck2").prop('checked',false).text("refresh");
  } else {
     text.style.display = "none";
  }
}
function myFunction2() {
var checkBox2 = document.getElementById("myCheck2");
var text = document.getElementById("hidden_fields");
  if (checkBox2.checked == true){
    text.style.display = "none";
    $("#myCheck1").prop('checked',false).checkboxradio("refresh");
     $("#myCheck1").prop('checked',false).text("refresh");
  } 
}
</script>

<style>
body{
  background-image: url('mm1.jpg');
  background-size: cover;
}
.page-header{
  margin-left:400px;
}
</style>

</head>

<body style="margin-left: 600px;margin-top: 50px;">

  <div class="page-header">
    <h1>Market Management
      <small>Form</small></h1>
  </div><br>

  <form method="post">
    <?php include '1.php'; ?>
   	        <div>
                <b>Customization:</b>  <input type="checkbox" id="myCheck1" name="required"  onclick="myFunction1()">
                                  <label for="Required">Required</label>
                 				         <input type="checkbox" id="myCheck2" name="not"  onclick="myFunction2()">
                                  <label for="Required">Not</label>
    				</div>
    				<div id="hidden_fields" style="display:none;">
    					<label for="Custom Type">Custom Type</label>
        					<select class="form-control" id='select_2' name="customtype" style="width:40%;" >
          					<option>Logos</option>
        						<option>Columns</option>
        						<option>Model</option>
        						<option>Attaire</option>
        					</select><br><br>
    					<label for="Actual Data">Actual Data :</label>
                <input type="file" id="fileUpload" class="form-control" name="FileUpload" multiple="" style="width:40%;" /><br><br>               
    					<label for="Quantity">Quantity :</label>
                <input type="text" class="form-control" name="quantity" id="hidden_field" style="width:40%;"><br><br>
    				  <label for="Thread Count">Thread Count :</label>
                <input type="text" class="form-control" name="threadcount" id="hidden_field" style="width:40%;"><br><br>
    			  </div>		
        <input type="submit" name="submit" class="btn btn-primary"> 
        <input type="reset" name="reset" class="btn btn-danger">
      </form>
      
</body> 
</html>