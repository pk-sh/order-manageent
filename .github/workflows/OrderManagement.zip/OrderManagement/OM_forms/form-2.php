<!DOCTYPE html>
<html>
<head>
	<title>Order Management</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <script>
$(function(){
  $("#hidden_fields").hide();
  $("#myCheck1").click(function(){
    if($("#myCheck1").is(':checked')){
      $("#hidden_fields").show();
      $("#myCheck2").prop('checked',false).checkboxradio("refresh");
    }else{
      $("#hidden_fields").hide();
    }
  });
  $("#myCheck2").click(function(){
    if($("#myCheck2").is(':checked')){
      $("#hidden_fields").hide();
      $("#myCheck1").prop('checked',false).checkboxradio("refresh");
    }
  });
});
</script>
<style>
body{
background-image: url("mm2.jpg");
background-size: cover;
}
.page-header{
  margin-left:400px;
}
</style>
</head>
<body style="margin-left: 600px;margin-top: 100px;">
  <div class="page-header">
    <h1>Order Management
      <small>Form</small></h1>
  </div><br>
  
				<div class="row col-md-8" style="margin-bottom: 30px;">
  					<label for="order date">Order Date :</label>
            <input type="date" class="form-control" style="width:40%;">
        </div>
        <div class="row col-md-8">				
  				  <label for="Expected delivery">Expected Delivery :</label>
            <input type="date" class="form-control" style="width:40%;">
        </div>         
            <div class="row col-md-8" style="margin-top: 30px;">
                <b>Goods Transaction</b> :&nbsp<input type="checkbox" id="myCheck1">
                                    <label for="Required">Required</label>
       				                     <input type="checkbox" id="myCheck2">
                                   <label for="Required">Not</label>
            </div>
           
        			<div id="hidden_fields">
                      <div class="row col-md-8" style="margin-top: 30px;">
                    				<label for="vehicle Type">Vechicle Type </label>
                    					<select class="form-control" id='select_2' style="width:40%;" >
                    					    <option>Two-Wheeler</option>
                    					    <option>Three-Wheeler</option>
                    						  <option>Four-Wheeler</option>
                        			</select><br><br>
                      </div>
                  <div class="row col-md-8">
                          <label for="vehicle details">Vechicle Details </label> 
                          <input type="Text" class="form-control" style="width:40%;"/>
                  </div>
                  <div class="row col-md-8" style="margin-top: 20px;">
                      Acknowledge Required :<input type="checkbox">
                                          <label for="Required">Yes</label>
                                          <input type="checkbox">                                 
                                          <label for="Required">Not</label>
                  </div>
                </div>
                  <div class="row col-md-8" style="margin-top: 30px;">
                	    <input type="submit" name="submit" class="btn btn-primary">&nbsp&nbsp  
                      <input type="reset" name="reset" class="btn btn-danger">
                  </div>
          					
  			</div>
      </form>
    </body>
  </html>
  