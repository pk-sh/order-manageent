<!DOCTYPE html>
<html>
<head>
	<title>Dispatch</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
function myFunction1() {
  var checkBox1 = document.getElementById("myRadio1");
  var text = document.getElementById("hidden_fields1");
  if (checkBox1.checked == true){
    text.style.display = "block";
    $("#myRadio2").prop('checked',false).checkboxradio("refresh");
    $("#myRadio2").prop('checked',false).text("refresh");
  } else {
     text.style.display = "none";
  }
}
function myFunction2() {
var checkBox2 = document.getElementById("myRadio2");
var text = document.getElementById("hidden_fields1");
  if (checkBox2.checked == true){
    text.style.display = "none";
    $("#myRadio1").prop('checked',false).checkboxradio("refresh");
    $("#myRadio2").prop('checked',false).text("refresh");
  } 
}
function myFunction3() {
  var checkBox3 = document.getElementById("myRadio3");
  var text = document.getElementById("hidden_fields2");
  if (checkBox3.checked == true){
    text.style.display = "block";
    $("#myRadio4").prop('checked',false).checkboxradio("refresh");
    $("#myRadio2").prop('checked',false).text("refresh");
  } else {
     text.style.display = "none";
  }
}
function myFunction4() {
var checkBox4 = document.getElementById("myRadio4");
var text = document.getElementById("hidden_fields2");
  if (checkBox4.checked == true){
    text.style.display = "none";
    $("#myRadio3").prop('checked',false).checkboxradio("refresh");
    $("#myRadio2").prop('checked',false).text("refresh");
  } 
}
function myFunction5() {
  var checkBox5 = document.getElementById("myRadio5");
  var text = document.getElementById("hidden_fields3");
  if (checkBox5.checked == true){
    text.style.display = "block";
    $("#myRadio6").prop('checked',false).checkboxradio("refresh");
    $("#myRadio2").prop('checked',false).text("refresh");
  } else {
     text.style.display = "none";
  }
}
function myFunction6() {
var checkBox6 = document.getElementById("myRadio6");
var text = document.getElementById("hidden_fields3");
  if (checkBox6.checked == true){
    text.style.display = "none";
    $("#myRadio5").prop('checked',false).checkboxradio("refresh");
    $("#myRadio2").prop('checked',false).text("refresh");
  } 
}

</script>
<style>
body{
background-image: url("mm3.jpg");
background-size: cover;
}
.page-header{
  margin-left:500px;
}
</style>
</head>
  <body style="margin-left: 600px;margin-top: 50px;">
  	<div class="page-header">
    <h1>Dispatch
      <small style="color:black;">Form</small></h1>
  </div><br>
  	<form method="post" action="mm1.php">
  		<div>
  		  <b>Customization Order:</b> 
        <input type="radio" id="myRadio1" name="required"  onclick="myFunction1()">
        <label for="yes">yes</label>
        <input type="radio" id="myRadio2" name="not"  onclick="myFunction2()">
        <label for="no">No</label>
    	</div><br>
    	<div id="hidden_fields1" style="display:none;">
    					<label for="Custom Details">Customization Details</label>
    					 <input type="text" id="select_1" class="form-control" style="width:40%;" name="customization details">
    	</div><br>
    	<div>
    		<b>Order Ready ?:</b><input type="radio" id="myRadio3" name="required"  onclick="myFunction3()">
                          <label for="yes">yes</label>
                          <input type="radio" id="myRadio4" name="not"  onclick="myFunction4()">
                          <label for="no">no</label>
        </div><br>
        <div id="hidden_fields2" style="display:none;">
        	<div style="margin-top: 30px;">
                    				<label for="vehicle Type">Vechicle Type </label>
                    					<select class="form-control" id='select_2' style="width:40%;" >
                    					    <option>Company Vehicle</option>
                    					    <option>Customer Vehicle</option>
                        				</select><br><br>
            </div><br>
            <div>
                    <label for="vehicle no">Vechicle Number </label> 
                    <input type="int" class="form-control" style="width:40%;"/>
            </div><br>
           <div>
    		<b>Ready for Dispatch ?:</b><input type="radio" id="myRadio5" name="required" onclick="myFunction5()">
                          <label for="no">yes</label>
                          <input type="radio" id="myRadio6" name="not"  onclick="myFunction6()">
                          <label for="no">no</label>
        	</div><br>
        	<div id="hidden_fields3" style="display:none;">
    					<label for="dispatch date">Dispatch Date</label>
    					 <input type="date" id="select_3" name="dispatch date">
    	</div><br>
        </div>
        <input type="submit" name="submit" class="btn btn-primary"> 
    	
</form>
</body>
</html>
