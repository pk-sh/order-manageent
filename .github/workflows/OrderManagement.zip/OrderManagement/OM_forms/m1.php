<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "market_management";
$conn = mysqli_connect( $servername,$username,$password,$dbname);
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}
 if(isset($_POST['submit'])){
        $sql = "INSERT INTO market (materialtype, clothtype, customtype,quantity,threadcount)
        VALUES ('".$_POST["materialtype"]."','".$_POST["clothtype"]."','".$_POST["customtype"]."','".$_POST["quantity"]."','".$_POST["threadcount"]."')";
    }
if(mysqli_query($conn,$sql)){
	echo"values inserted successfully";
}else{
	echo"error inserting record:".mysqli_error($conn);
}
mysqli_close($conn);
?>