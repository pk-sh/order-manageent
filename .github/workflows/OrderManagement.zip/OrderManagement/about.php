<?php
  session_start(); 
   //echo $_SESSION['username']; exit;
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }

  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>ORDER MANAGEMENT | ABOUT US</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/order-management.css" rel="stylesheet">
    <style>
    body{
      background-image: url("images/image1_gif.gif");
      background-repeat: no-repeat;
      background-size: cover;
      color: #3f8ba3;
    }
       #zoom img{
        border-radius: 80px;
        transition: all 1s;
        cursor: pointer;
      }
        #zoom:hover img{
          transform: scale(1.1,1.1);
      }
       
    </style>
  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">ORDER MANAGEMENT</a>

           <!-- logged in user information -->
           <div>
              <?php  if (isset($_SESSION['username'])) : ?>
                <p style="color: #7f888f; margin: 0 auto;">Welcome <strong><?php echo ucfirst($_SESSION['username']); ?></strong></p>
              <?php endif ?>
            </div>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="about.php">About</a>
            </li>
           
             <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Services
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
                <a class="dropdown-item" href="orderform_1.php">Orderform_1</a>
                <a class="dropdown-item" href="orderform_2.php">Orderform_2</a>
                <a class="dropdown-item" href="dispatch_form.php">Dispatch Form</a>
                <a class="dropdown-item" href="feedback.php">Feedback</a>
              </div>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="logout.php">Logout</a>
            </li>
            
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page Content -->

     <div class="container">
      
      <!-- Introduction Row -->
      <h1 class="my-4" style="color: #fff;">About Us
        <small style="color: #6d7d8b;">It's Nice to Meet You!</small>
      </h1>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint, explicabo dolores ipsam aliquam inventore corrupti eveniet quisquam quod totam laudantium repudiandae obcaecati ea consectetur debitis velit facere nisi expedita vel?</p>

      <!-- Team Members Row -->
      <div class="row">
        <div class="col-lg-12">
          <h2 class="my-4">Our Team</h2>
        </div>
        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <div id="zoom">
              <img class="rounded-circle img-fluid d-block mx-auto" src="images/pk_4.png" alt="">
          </div>
          <h3 style="color: #96afc2;">Piyush
            <small>Web Developer</small>
          </h3>
          <p>What does this team member to? Keep it short!<a href="https://www.facebook.com/piyush3sharm">Know More..</a></p>
        </div>

        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <div id="zoom">
              <img class="rounded-circle img-fluid d-block mx-auto" src="images/rahul.jpg" alt="">
          </div>
          <h3 style="color: #96afc2;">Rahul
            <small>Java Developer</small>
          </h3>
          <p>What does this team member to? Keep it short!<a href="https://www.facebook.com/rahul.ran.2008">Know More..</a></p>
        </div>

        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <div id="zoom">
              <img class="rounded-circle img-fluid d-block mx-auto" src="images/jyotish.jpg" alt="">
          </div>
          <h3 style="color: #96afc2;">Jyotish
            <small>Java developer</small>
          </h3>
          <p>What does this team member to? Keep it short! <a href="https://www.facebook.com/jyotish.kumar.908">Know More..</a></p>
        </div>

        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <div id="zoom">
              <img class="rounded-circle img-fluid d-block mx-auto" src="images/vijay.jpg" alt="">
          </div>
          <h3 style="color: #96afc2;">Vijay
            <small>Python Developer</small>
          </h3>
          <p>What does this team member to? Keep it short! <a href="https://www.facebook.com/profile.php?id=100002610323056">Know More..</a></p>
        </div>

        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <div id="zoom">
              <img class="rounded-circle img-fluid d-block mx-auto" src="images/pk_5.png" alt="">
          </div>
          <h3 style="color: #96afc2;">Piyush
            <small>Web Developer</small>
          </h3>
          <p>What does this team member to? Keep it short! <a href="#">Know More..</a></p>
        </div>

        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <div id="zoom">
              <img class="rounded-circle img-fluid d-block mx-auto" src="images/pk_7.png" alt="">
          </div>
          <h3 style="color: #96afc2;">Piyush
            <small>Web Developer</small>
          </h3>
          <p>What does this team member to? Keep it short! <a href="#">Know More..</a></p>
        </div>
      </div>

    </div>
    <!-- /.container -->


    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
