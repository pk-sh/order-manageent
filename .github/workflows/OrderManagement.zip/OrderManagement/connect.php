<?php 
	$con = mysqli_connect("localhost","root","","order_management") or die("Unable to Connect to the Database");
?>