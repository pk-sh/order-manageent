
 <?php 

  if (isset($_POST['register']))
  {
    $username = $_POST['username']; // fetching data f
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password_1 = md5($_POST['password_1']);
    $password_2 = md5($_POST['password_2']);
   

    include('connect.php'); // connecting to the database

     mysqli_query($con, "insert into users(username,email,mobile,password)
           values ('$username','$email','$mobile','$password_1')");

    if(mysqli_affected_rows($con)==1)
    {
      echo "<center>Your Account Has Been Created Successfully..!!</center>";
    }
    else
    {
      echo "<center>Sorry!! Unable To Create</center>";
    }

  }
   ?>