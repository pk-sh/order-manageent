<?php
  session_start(); 
   //echo $_SESSION['username']; exit;
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }

  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>ORDER MANAGEMENT | CONTACT</title>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/order-management.css" rel="stylesheet">
    <style>
    </style>
    <script>
      function contactValidation(){
        if (document.getElementById('name').value=="")
         {
            document.getElementById('name').style.border="1 px solid red";
            document.getElementById('name_error').style.color="#f00";
            document.getElementById('name').focus();
            document.getElementById('name_error').innerHTML="Name is Required";
            return false;
         }
         if (document.getElementById('mobile').value=="")
          {
            document.getElementById('mobile').style.border="1 px solid red";
            document.getElementById('mobile_error').style.color="#f00";
            document.getElementById('mobile').focus();
            document.getElementById('mobile_error').innerHTML="Mobile no. is Required";
            return false;
          }
          else
          {
           var mobile=document.getElementById("mobile").value;
           var mpat=/^\d{10}$/;
           if(!mpat.test(mobile))
            {
             document.getElementById("mobile").style.border="1px solid red";
             document.getElementById("mobile_error").style.color="#f00";
             document.getElementById("mobile").focus();
             document.getElementById("mobile_error").innerHTML="Please Enter a Valid 10 Digit Mobile Number";
             return false;
            }
         }

          if (document.getElementById('email').value=="")
           {
            document.getElementById('email').style.border="1 px solid red";
            document.getElementById('email_error').style.color="#f00";
            document.getElementById('email').focus();
            document.getElementById('email_error').innerHTML="Email is Required";
            return false;
           }
            else
             {
              var email=document.getElementById('email').value;
              var pat=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
              
              if(!pat.test(email))
              {
              document.getElementById('email').style.border="1px solid red";
              document.getElementById('email_error').style.color="#f00";
              document.getElementById('email').focus();
              document.getElementById('email_error').innerHTML="Please enter a valid Email";
              return false;
              }
        
            }
      }
      function checkValue(ele)
      {
          if(ele.value!="")
        {
          ele.style.border="1px solid #999";
          document.getElementById(ele.id+"_error").innerHTML="";
        }
     }
    </script>
  </head>
  <body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">ORDER MANAGEMENT</a>

         <!-- logged in user information -->
              <?php  if (isset($_SESSION['username'])) : ?>
                <p style="color: #7f888f; margin: 0 auto;">Welcome <strong><?php echo ucfirst($_SESSION['username']); ?></strong></p>  
              <?php endif ?>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">About</a>
            </li>
           
             <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Services
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
                <a class="dropdown-item" href="orderform_1.php">Orderform_1</a>
                <a class="dropdown-item" href="orderform_2.php">Orderform_2</a>
                <a class="dropdown-item" href="dispatch_form.php">Dispatch Form</a>
                <a class="dropdown-item" href="feedback.php">Feedback</a>
              </div>
            </li>

            <li class="nav-item active">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php">Logout</a>
            </li>
             
          </ul>
        </div>
      </div>
    </nav>
    <br>
   <?php include('server.php'); ?>

    <!-- Page Content -->
      <div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3">Contact</h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">Contact</li>
      </ol>

      <!-- Content Row -->
      <div class="row">
        <!-- Map Column -->
        <div class="col-lg-8 mb-4">
          <!-- Embedded Google Map -->
          <iframe width="100%" height="400px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?hl=en&amp;ie=UTF8&amp;ll=37.0625,-95.677068&amp;spn=56.506174,79.013672&amp;t=m&amp;z=4&amp;output=embed"></iframe>

          
        </div>
        <!-- Contact Details Column -->
        <div class="col-lg-4 mb-4">
          <h3>Contact Details</h3>
          <p>
            Annapurna Boys hostel Balkampet,<br>Hyderabad
            <br>
          </p>
          <p>
            Mobile No: 9999999999
          </p>
          <p>
           Email: <a href="mailto:ordermanagement@gmail.com">ordermanagement@gmail.com</a>
          </p>
          
        </div>
        
      </div>
      <!-- /.row -->

      <!-- Contact Form -->
      <!-- In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
      <div class="row">
        <div class="col-lg-8 mb-4">

          <h3>Send us a Message</h3>
          <form action="" name="sentMessage" id="contactForm" class="form-horizontal" method="POST" onsubmit="return contactValidation()">
            <div class="control-group form-group">
              <div class="controls">
                <label>Full Name:</label>
                <input type="text" onblur="checkValue(this)" class="form-control" id="name" name="contact_name" placeholder="Enter Full Name">
                 <span id="name_error" style="color:red;"></span>
              </div>
            </div>
            <div class="control-group form-group">
              <div class="controls">
                <label>Mobile Number:</label>
                <input type="tel" onblur="checkValue(this)" class="form-control" id="mobile" name="contact_mobile" placeholder="Enter Mobile no.">
                 <span id="mobile_error" style="color:red;"></span>
              </div>
            </div>
            <div class="control-group form-group">
              <div class="controls">
                <label>Email Address:</label>
                <input type="email" onblur="checkValue(this)" class="form-control" id="email" name="contact_email" placeholder="Enter email here">
                 <span id="email_error" style="color:red;"></span>
              </div>
            </div>
            <div class="control-group form-group">
              <div class="controls">
                <label>Message:(Optional)</label>
                  <textarea rows="10" onblur="checkValue(this)" cols="100" name="contact_message" class="form-control" id="message" required="Please Enter Your Message" maxlength="999" style="resize:none">
                  
                  </textarea>
              </div>
            </div>
            <div id="success"></div>
            <!-- For success/fail messages -->
            <button type="submit" class="btn btn-primary" name="contact" id="sendMessageButton" onsubmit="contactValidation();">Send Message</button>
          </form>
        </div>

      </div>
      <!-- /.row -->
    </div>
    <!-- /.container -->

     <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
      </div>

      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>