<!DOCTYPE html>
<html>
<head>
	<title>Delivery</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="">
  <style>
    body{
          background-image: url("images/ODESZA-Backgrounds-Desktop-1080.jpg");
          background-size: cover;
          }
          .page-header{
            margin-left:200px;
          }

          .rating-stars ul {
            list-style-type:none;
            padding:0;
          }
          .rating-stars ul > li.star {
            display:inline-block;
          }

          /* Idle State of the stars */
          .rating-stars ul > li.star > i.fa {
            font-size:2em; 
            font-color: blue;
          }
          /* Selected state of the stars */
          .rating-stars ul > li.star.selected > i.fa {
            color:red;
          }
          #deliveryForm{
            color: #448aa4;
          }

  </style>
  <script>
  	$(document).ready(function(){
  $('#stars li').on('click', function(){
    var onStar = parseInt($(this).data('value')); 
    var stars = $(this).parent().children('li.star');
    
    for (i = 0; i <stars.length; i++) {
      $(stars[i]).removeClass('selected');
    }
    
    for (i = 0; i < onStar; i++) {
      $(stars[i]).addClass('selected');
    }
  });
});
</script>
</head>
  <body style="margin-left: 200px;margin-top: 50px;" id="deliveryForm">
  	<div class="page-header">
    <h1>Delivery
      <small style="color:black;">Form</small></h1>
  </div><br>
  	<form method="post">
  		<div style="margin-top: 30px;">
        <label for="vehicle Type">Delivery Details: </label>
          <select class="form-control" id='select_2' style="width:40%;" >
            <option>Dispatched</option>
            <option>Handover</option>
          </select>
      </div>
      <br><div>

    		<b>Ontime Delivered ?:</b><input type="radio" name="required">
          <label for="yes">yes</label>
            <input type="radio" name="required" >
          <label for="no">no</label>
        </div><br>
        <div>
        	<b>Comments:</b><textarea class="form-control" rows='6' style="width:40%;"></textarea><br>
        </div>
        <b>Feedback: </b>
        <div class='rating-stars inline'>
          <ul id='stars'>
            <li class='star' title='Poor' data-value='1'>
              <i class='fa fa-star fa-fw'></i>
            </li>
            <li class='star' title='Fair' data-value='2'>
              <i class='fa fa-star fa-fw'></i>
            </li>
            <li class='star' title='Good' data-value='3'>
              <i class='fa fa-star fa-fw'></i>
            </li>
            <li class='star' title='Excellent' data-value='4'>
              <i class='fa fa-star fa-fw'></i>
            </li>
            <li class='star' title='WOW!!!' data-value='5'>
              <i class='fa fa-star fa-fw'></i>
            </li>
          </ul>
        </div>
        <input type="submit" name="submit" class="btn btn-primary">
	</form>
</body>
</html>