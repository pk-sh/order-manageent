<?php 
  if (isset($_POST['submit']))
    {
      $delivery_details = $_POST['delivery_details'];
      $ontime_delivered=(isset($_POST['radio']))?$_POST['radio']:"";
      $comments = $_POST['comments'];
      //$feedback = $_POST['feedback'];

      $con = mysqli_connect("localhost","root","","order_management") or die("Unable to Connect");

             mysqli_query($con,"insert into feedback(delivery_details,ontime_delivered,comments,feedback) 
                                values('$delivery_details','$ontime_delivered','$comments','$feedback')");

      if(mysqli_affected_rows($con)==1)
      {
        echo "<center style='color:green; font-size:20px;'>Feedback Sent Successfully</center>";
      }
      else
      {
        echo "<center style='color:red; font-size:20px;'>Sorry!! Unable To Sent Feedback Data, Please Try Again.....</center>";
      }
  
    }  
?>
<center><a href="feedback.php">GO BACK</a></center>