<!DOCTYPE html>
<html lang="en">
  <head>
    <title>ORDER MANAGEMENT | LOGIN</title>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/order-management.css" rel="stylesheet">
    <link href="css/fontawesome.min.css" rel="stylesheet">
    <link href="css/fontawesome.css" rel="stylesheet">
    <style>
       #login-body{
          background: url('images/image1_gif.gif');
          background-repeat: no-repeat;
          background-size: cover;   
       }
       footer{
        
        position:relative; 
       }
    </style>

    <script>
      function loginValidation(){
          if (document.getElementById('name').value=="")
           {
              document.getElementById('name').style.border="1px solid red";
              document.getElementById('name_error').style.color="#f00";
              document.getElementById('name').focus();
              document.getElementById('name_error').innerHTML="Username is required";
              return false;
           }
           if(document.getElementById('password').value=="")
           {
            document.getElementById('password').style.border="1px solid red";
            document.getElementById('password_error').style.color="#f00";
            document.getElementById('password').focus();
            document.getElementById('password_error').innerHTML="Password is required";
            return false;
           }
        }
        function checkValue(ele)
        {
          if(ele.value!="")
           {
             ele.style.border="1px solid #999";
            document.getElementById(ele.id+"_error").innerHTML="";
           }
         }
    </script>
  </head>
  <body id="login-body">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">ORDER MANAGEMENT</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            
             <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="login.php">Login</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    

    <!-- Page Content -->
      <div class="container">
      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3" style="color: #fff;">Login</h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="login.php">Home</a>
        </li>
        <li class="breadcrumb-item active">Login</li>
      </ol>

      <!-- login Form -->
      
      <div class="row">
        <div class="col-lg-8 mb-4">

          <?php include('server.php'); ?>

          <h3 style="color: #fff;">Please Login Here</h3>
          <form action="" name="sentMessage" id="loginForm" class="form-horizontal" method="POST" onsubmit="return loginValidation()">
            <div class="control-group form-group">
              <div class="controls">
                <label style="color: #fff;">User Name:</label>
                <input type="text" onblur="checkValue(this)" class="form-control" name="username" id="name" placeholder="Enter Name ">
                <span id="name_error" style="color:red;"></span>
                
              </div>
            </div>
            <div class="control-group form-group">
              <div class="controls">
                <label style="color: #fff;">Password:</label>
                <input type="password" onblur="checkValue(this)" class="form-control" name="password" id="password" placeholder="Enter Password">
                <span id="password_error" style="color:red;"></span>
              </div>
            </div>
            
            <div id="success"></div>
            <!-- For success/fail messages -->
            <button type="submit" class="btn btn-primary" name="login" id="sendLoginButton" onsubmit="loginValidation();">Login</button>
            &nbsp;
            <a href="change_pwd.php" style="text-decoration: none;">Forgot Password?</a>&nbsp;
            <a href="register.php" style="text-decoration: none;">Create Account?</a>
          </form>
        </div>

      </div>
      <!-- /.row -->
    </div>
    <!-- /.container -->
    <br>
    
     <!-- Footer -->
    <!--<footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
      </div>

      <! /.container -->
    <!--</footer>

     Bootstrap core JavaScript 
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  -->

  </body>

</html>