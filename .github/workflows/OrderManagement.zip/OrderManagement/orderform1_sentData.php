<?php 

	    include('connect.php');
		$material_type = $_POST['material_type'];
		$cloth_type = $_POST['cloth_type'];
		$goods_transportation=(isset($_POST['goods']))?$_POST['goods']:"";
		$custom_data = $_POST['custom_data'];
		$actual_data = $_POST['actual_data'];
		$quantity = $_POST['quantity'];
		$thread_per_cm = $_POST['thread_per_cm'];
		$ip=$_SERVER['REMOTE_ADDR'];

		$result = mysqli_query($con,"insert into                           orderform_1(material_type,cloth_type,goods_transportation,custom_data,actual_data,quantity,thread_per_cm,ip)
							values('$material_type','$cloth_type','$goods_transportation','$custom_data','$actual_data','$quantity',
							'$thread_per_cm','$ip')");

		 if(!$result)
		 {
		 	echo "<center style='color:red; font-size:20px;'>Sorry!! Unable To Sent Data, Please Try Again.....</center>";

		 }
		 else
		 {
		 	echo "<center style='color:green; font-size:20px;'>Your Order Data Sent Successfully!!</center>";
		 }
	
	
?>
<a href="orderform_1.php">GO BACK</a>