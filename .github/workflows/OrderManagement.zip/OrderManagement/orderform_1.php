<!DOCTYPE html>
<html>
<head>
  <title>ORDER MANAGEMENT | FORM 1</title>
 <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/order-management.css" rel="stylesheet">
    <style>
      #orderForm_1{
        background: url('images/ODESZA-Backgrounds-Desktop-1080.jpg');
        background-repeat: no-repeat;       
      }
       #orform_1{
        color: #448aa4;
      }

    </style>
    <script>
        $(document).ready(function(){
          $("required").click(function(){
            $("jq_fun").show();
          });
          $("notrequired").click(function(){
            $("jq_fun").hide();
          });
        });
      
    </script>
</head>
  <body style="margin-left: 300px;margin-top: 30px;" id="orderForm_1">

        <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">ORDER MANAGEMENT</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">About</a>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Services
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
                <a class="dropdown-item" href="orderform_1.php">Orderform_1</a>
                <a class="dropdown-item" href="orderform_2.php">Orderform_2</a>
                <a class="dropdown-item" href="dispatch_form.php">Dispatch Form</a>
                <a class="dropdown-item" href="feedback.php">Feedback</a>
              </div>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link" href="logout.php">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

  <div class="container">
    <div class="row">
      <div class=" col-md-offset-4 col-md-4">
        <form method="POST" action="orderform1_sentData.php">
          <div id="orform_1">
          <h2 style="color:#80bec1;">ORDER FORM_1</h2>
          <div class="form-group">    
            <label for="Material Type">Material Type:</label>
              <select class="form-control" id="MainDDl" name="material_type">
                <option>Fabrics</option>
                <option>Readymade</option>    
              </select>
          </div>  
        <div>
          <div class="form-group">    
            <label for="cloth type">cloth type:</label>
            <select class="form-control" id="SelectedDdl" name="cloth_type">
              <option>cloth</option>
              <option>bedsheet</option>  
            </select>

         
          </div>  
        </div>
          
        </br>

          <div class="form-group">  
            <label>Goods Transportation:</label>
            <br>
            <tr>
              <td>
                <input type="radio" name="goods" id="required" value="required">Required
                 <br>
                <input type="radio" name="goods" id="notrequired" value="not">Not
              </td>
            </tr>
              
          </div>
          
          <div class="form-group" id="jq_fun">    
            <label for="custom data">custom data:</label>
            <select class="form-control" id="" name="custom_data">
              <option>logo</option>
              <option>colours</option>
              <option>Modal</option>
              <option>Attaire</option>   
            </select>
          </div>       
          </br>

          <div class="form-group">
            <label for="Actual Data">Actual Data:</label>
            <input type="text" class="form-control" id="jq_fun" name="actual_data">
          </div></br>
          <div class="form-group">
            <label for="Quantity">Quantity:</label>
            <input type="text" class="form-control" id="jq_fun" name="quantity">
          </div></br>
          <div class="form-group">
            <label for="Thread per cm">Thread per cm:</label>
            <input type="text" class="form-control" id="jq_fun" name="thread_per_cm">
          </div>
      </div>

      </br> 
          <div class="form-group">            
            <input type="submit" name="submit" class="btn btn-md btn-info" value="Submit">
            <input type="submit" name="reset" class="btn btn-md btn-danger" value="Reset" id="reset">
          </div>
          </div>
      </form>
     </div>

 </body>
</html>