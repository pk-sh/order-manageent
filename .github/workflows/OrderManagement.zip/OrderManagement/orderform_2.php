<!DOCTYPE html>
<html lang="en">
  <head>
    <title>ORDER MANAGEMENT | FORM 2</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/order-management.css" rel="stylesheet">
    
     <style>
      #orderForm_2{
        background: url('images/ODESZA-Backgrounds-Desktop-1080.jpg');
        background-repeat: no-repeat;       
      }
      #orform_2{
        color: #448aa4;
      }

    </style>
    <script>
      
    </script>
  </head>
  <body style="margin-left: 300px;margin-top: 30px;" id="orderForm_2">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">ORDER MANAGEMENT</a>

          <!-- logged in user information -->
              <?php  if (isset($_SESSION['username'])) : ?>
                <p style="color: #7f888f; margin: 0 auto;">Welcome <strong><?php echo ucfirst($_SESSION['username']); ?></strong></p> 
              <?php endif ?>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">About</a>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Services
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
                <a class="dropdown-item" href="orderform_1.php">Orderform_1</a>
                <a class="dropdown-item" href="orderform_2.php">Orderform_2</a>
                <a class="dropdown-item" href="dispatch_form.php">Dispatch Form</a>
                <a class="dropdown-item" href="feedback.php">Feedback</a>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Nav Close -->

    <div class="container">
      <div class="row">
        <div class="col-md-offset-4 col-md-4">
          <form method="POST" action="">
            <div id="orform_2">
            <h2 style="color:#80bec1;">ORDER FORM_2</h2>
            <div class="form-group">
              <label for="Order Date">Order Date:</label>
              <input type="date" class="form-control" id="">
            </div>
            <div class="form-group">
              <label for="Expected Delivery Date">Expected Delivery Date:</label>
              <input type="date" class="form-control" id="">
            </div>
            <div class="form-group">  
              <label>Goods Transportation:</label>
            <br>
            <tr>
              <td>
                <input type="radio" name="goods" id="required" value="required">Required
                 <br>
                <input type="radio" name="goods" id="notrequired" value="not">Not
              </td>
            </tr>
            </div>
          <div class="Paida">

              <div class="form-group">
                <label for="Vehical type">Vehical Type:</label>
                <select class="form-control" id="">
                  <option>Hyundai</option>
                  <option>Maruthi</option>
                  <option>Audi</option>
                  <option>Benz</option>
                </select>
              </div>
              <div class="form-group">
                <label for="Vehical Details">Vehical Details:</label>
                <input type="text" class="form-control" id="">
              </div>
          </div>
          </div>
          </form>
            <div class="form-group">
              <input type="button" class="btn btn-info" value="Submit">
              <input type="button" class="btn btn-danger" value="Reset">
            </div>
          </div>
          </div>
        
      </div>
      
    </div>

    </body>
    </html>