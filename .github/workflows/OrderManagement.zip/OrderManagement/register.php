 <?php 
   @session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>ORDER MANAGEMENT | REGISTER</title>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/order-management.css" rel="stylesheet">
    <style>
      #reg-body{
        background: url('images/image1_gif.gif');
        background-repeat: no-repeat;     
        background-size: cover;  
      }

    </style>
    <script>
      function regValidation()
    {
      if(document.getElementById('name').value=="")
      {
        document.getElementById('name').style.border="1px solid red";
        document.getElementById('name_error').style.color="#f00";
        document.getElementById('name').focus();
        document.getElementById('name_error').innerHTML="User is required";
        return false; 
      }
      if (document.getElementById('email').value=="")
       {
        document.getElementById('email').style.border="1px solid red";
        document.getElementById('email_error').style.color="#f00";
        document.getElementById('email').focus();
        document.getElementById('email_error').innerHTML="Email is required";
        return false; 
       }
       else
      {
        var email=document.getElementById('email').value;
        var pat=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        
        if(!pat.test(email))
        {
        document.getElementById('email').style.border="1px solid red";
        document.getElementById('email_error').style.color="#f00";
        document.getElementById('email').focus();
        document.getElementById('email_error').innerHTML="Please enter a valid Email";
        return false;
        }
        
      }
      if(document.getElementById('password').value=="")
      {
        document.getElementById('password').style.border="1px solid red";
        document.getElementById('password_error').style.color="#f00";
        document.getElementById('password').focus();
        document.getElementById('password_error').innerHTML="Password is required";
        return false; 
      }
      if(document.getElementById('cpassword').value=="")
      {
        document.getElementById('cpassword').style.border="1px solid red";
        document.getElementById('cpassword_error').style.color="#f00";
        document.getElementById('cpassword').focus();
        document.getElementById('cpassword_error').innerHTML=" Confirm Password is required";
        return false;
      }
      if(document.getElementById('password').value!=document.getElementById('cpassword').value)
      {
        document.getElementById('cpassword').style.border="1px solid red";
        document.getElementById('cpassword_error').style.color="#f00";
        document.getElementById('cpassword').focus();
        document.getElementById('cpassword_error').innerHTML="Password does not matche";
        return false;
      }
      if(document.getElementById("mobile").value=="")
        {
          document.getElementById("mobile").style.border="1px solid red";
          document.getElementById("mobile_error").style.color="#f00";
          document.getElementById("mobile").focus();
          document.getElementById("mobile_error").innerHTML="Mobile is Required";
          return false;
        }
        else
        {
          var mobile=document.getElementById("mobile").value;
          var mpat=/^\d{10}$/;
          if(!mpat.test(mobile))
          {
            document.getElementById("mobile").style.border="1px solid red";
          document.getElementById("mobile_error").style.color="#f00";
          document.getElementById("mobile").focus();
          document.getElementById("mobile_error").innerHTML="Please Enter a Valid 10 Digit Mobile Number";
          return false;
          }
        }
    }
   function checkValue(ele)
    {
      if(ele.value!="")
      {
        ele.style.border="1px solid #999";
        document.getElementById(ele.id+"_error").innerHTML="";
      }
    }
   
    </script>
  </head>
  <body id="reg-body">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">ORDER MANAGEMENT</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            
             <li class="nav-item active">
              <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <br>
    <!-- Connection-->
    <?php include('server.php'); ?>
   
    <!-- Page Content -->
      <div class="container">
      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3" style="color: #fff;">Register</h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">Register</li>
      </ol>

      <div class="row">
        <div class="col-lg-8 mb-4">
          <h3 style="color: #fff;">Please Register Here</h3>
          <form name="sentMessage" id="contactForm" class="form-horizontal" method="POST" action="" onsubmit="return regValidation()">
            <div class="control-group form-group">
              <div class="controls">
                <label style="color: #fff;">Full Name:</label>
                <input type="text" onblur="checkValue(this)" name="username" class="form-control" id="name" placeholder="Enter Name">
                <span id="name_error" style="color:red;"></span>
                <p class="help-block"></p>
              </div>
            </div>
            <div class="control-group form-group">
              <div class="controls">
                <label style="color: #fff;">Email:</label>
                <input type="email" onblur="checkValue(this)" name="email" class="form-control" id="email" placeholder="Enter Email Here">
                <span id="email_error" style="color:red;"></span>
              </div>
            </div>
            <div class="control-group form-group">
              <div class="controls">
                <label style="color: #fff;">Mobile:</label>
                <input type="tel" onblur="checkValue(this)"  name="mobile" class="form-control" id="mobile" placeholder="Enter Mobile No">
                <span id="mobile_error" style="color:red;"></span>
              </div>
            </div>
            <div class="control-group form-group">
              <div class="controls">
                <label style="color: #fff;">Password:</label>
                <input type="password" onblur="checkValue(this)" name="password_1" class="form-control" id="password" placeholder="Enter Password">
                <span id="password_error" style="color:red;"></span>
              </div>
            </div>
            <div class="control-group form-group">
              <div class="controls">
                <label style="color: #fff;">Confirm Password:</label>
                <input type="password" onblur="checkValue(this)" name="password_2" class="form-control" id="cpassword" placeholder="Enter Confirm Password">
                <span id="cpassword_error" style="color:red;"></span>
              </div>
            </div>
            
            <div id="success"></div>
            <!--<input type="text" hidden="" name="register">-->
            <!-- For success/fail messages -->
            <button type="submit" class="btn btn-primary" name="register" id="sendRegisterButton" onsubmit="regValidation();">Register</button>
          </form>
        </div>

      </div>
      <!-- /.row -->
    </div>
    <!-- /.container -->

     <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
      </div>

      <!-- /.container -->
    </footer>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  </body>
</html>