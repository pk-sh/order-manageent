 <?php 
   @session_start();

          //*************************  USER REGISTRATION  *****************
   
  if (isset($_POST['register']))
  {
    // fetching data from the register input boxes.
    $username = $_POST['username']; 
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password_1 = md5($_POST['password_1']);// converting password into 32 bit unreadable format
    $password_2 = md5($_POST['password_2']);
   
    include('connect.php'); // connecting to the database

     mysqli_query($con, "insert into users(username,email,mobile,password)
           values ('$username','$email','$mobile','$password_1')");

    if(mysqli_affected_rows($con)==1)
    {

      echo "<center style='color:green; font-size:20px;'><b>Your Account Has Been Created Successfully..!!<br>

          Click On Login and Login your Account</b></center>";

    }
    else
    {
      echo "<center style='color:red; font-size:20px;'>Sorry!! Unable To Create Account, Please Try Again.....</center>";
    }

  }
   ?>

          <!--**********************  CONTACT DATABASE  ************************ -->

   <?php 
      
      if (isset($_POST['contact']))
      {
        //Fetching all the data from contact boxes.
        $contact_name = $_POST['contact_name'];
        $contact_mobile = $_POST['contact_mobile'];
        $contact_email = $_POST['contact_email'];
        $contact_message = $_POST['contact_message'];

        // Database Connection 
        include('connect.php');

        // Inserting Queries 
        mysqli_query($con,"insert into contact(contact_name,contact_mobile,contact_email,contact_message) 
                                        values('$contact_name','$contact_mobile','$contact_email','$contact_message')");

        if(mysqli_affected_rows($con)==1)
          {
            echo "<center><p class='alert alert-success'>Your Message Send Successfully!!</p></center>";
          }
          else
          {
            echo "<center><p class='alert alert-danger'>Sorry!! Unable to Send Your Messages, Please Try Again....</p></center>";
          }

      }

   ?>

        <!--*********************   LOGIN DATABASE    ******************-->
<?php
    if (isset($_POST['login']))
    {
      $username = $_POST['username'];
      $password = $_POST['password'];

      include('connect.php');
      
        $password = md5($password);
        $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
        $resultset = mysqli_query($con, $query);
        $count = mysqli_num_rows($resultset);

        if($count>0){
    
          $row = mysqli_fetch_assoc($resultset);
          $_SESSION['user_id'] = $row['id'];

          $_SESSION['username'] =$row['username'];
           header("location:index.php");
           exit;
      } 
      else
      {
       echo "<center style='color:red; font-size20px;'><b>Wrong Username/Password Combination</b></center>";
      }
    
  }

  ?>