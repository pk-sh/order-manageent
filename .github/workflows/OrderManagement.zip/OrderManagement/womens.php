<?php
  session_start(); 
   //echo $_SESSION['username']; exit;
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }

  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>ORDER MANAGEMENT | WOMEN'S</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/order-management.css" rel="stylesheet">
    <style>
       #zoom img{
        transition: all 1s;
        cursor: pointer;
      }
        #zoom:hover img{
          transform: scale(1.1,1.1);
      }
       h2{
        font-family: Times New Roman;
        font-style: oblique;
       }
       .list-group a{
        font-family: Times New Roman;
        font-style: oblique;
        font-size: 20px;
       }
       h1{
        font-family: Times New Roman;
      
       }
       
    </style>
  </head>

  <body>
    <br>
    <center><h2>WOMEN'S ACCESSORIES</h2></center>
    <br>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">ORDER MANAGEMENT</a>

          <!-- logged in user information -->
           
              <?php  if (isset($_SESSION['username'])) : ?>
                <p style="color: #7f888f; margin: 0 auto;">Welcome <strong><?php echo ucfirst($_SESSION['username']); ?></strong></p>
              <?php endif ?>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="services.php">Services</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="logout.php">Logout</a>
            </li>
           
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <h1 class="my-4">Order Name</h1>

           <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="index.php">Home</a>
              </li>
                <li class="breadcrumb-item active">Women's</li>
            </ol>

          <div class="list-group">
            <a href="mens.php" class="list-group-item">Men's</a>
            <a href="womens.php" class="list-group-item">Women's</a>
            <a href="kids.php" class="list-group-item">Kid's</a>
          </div>
        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">
          
          <div class="row">

            <div class="col-lg-4 col-md-6 mb-4">
              <div class="card h-100">
                <div id="zoom">
                    <a href="#"><img class="card-img-top" src="images/700-400-lady's-jacket.jpg" alt=""></a>
                </div>
                <div class="card-body">
                  <h4 class="card-title">
                    <a href="#">Women's Jacket</a>
                  </h4>
                  <h5>$24.99</h5>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
              <div class="card h-100">
                <div id="zoom">
                  <a href="#"><img class="card-img-top" src="images/700-400.jpg" alt=""></a>
                </div>
                <div class="card-body">
                  <h4 class="card-title">
                    <a href="#">Collection's</a>
                  </h4>
                  <h5>$24.99</h5>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur! Lorem ipsum dolor sit amet.</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
              <div class="card h-100">
                <div id="zoom">
                  <a href="#"><img class="card-img-top" src="images/700-400-the-finder.jpg" alt=""></a>
                </div>
                <div class="card-body">
                  <h4 class="card-title">
                    <a href="#">The Finder</a>
                  </h4>
                  <h5>$24.99</h5>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
              <div class="card h-100">
                <div id="zoom">
                  <a href="#"><img class="card-img-top" src="images/700-400-red-girl.jpg" alt=""></a>
                </div>
                <div class="card-body">
                  <h4 class="card-title">
                    <a href="#">Red Girl</a>
                  </h4>
                  <h5>$24.99</h5>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
              <div class="card h-100">
                <div id="zoom">
                  <a href="#"><img class="card-img-top" src="images/700-400-udata.jpg" alt=""></a>
                </div>
                <div class="card-body">
                  <h4 class="card-title">
                    <a href="#">Udata Fashion</a>
                  </h4>
                  <h5>$24.99</h5>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur! Lorem ipsum dolor sit amet.</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
              <div class="card h-100">
                <div id="zoom">
                  <a href="#"><img class="card-img-top" src="images/700-400-tinder-date-fling.jpg" alt=""></a>
                </div>
                <div class="card-body">
                  <h4 class="card-title">
                    <a href="#">Tinder Date Finding</a>
                  </h4>
                  <h5>$24.99</h5>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
              <div class="card h-100">
                <div id="zoom">
                  <a href="#"><img class="card-img-top" src="images/700-400-master-denim-shorts.png" alt=""></a>
                </div>
                <div class="card-body">
                  <h4 class="card-title">
                    <a href="#">Denim Shorts</a>
                  </h4>
                  <h5>$24.99</h5>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
              <div class="card h-100">
                <div id="zoom">
                  <a href="#"><img class="card-img-top" src="images/700-400-stylish-adventures.jpg" alt=""></a>
                </div>
                <div class="card-body">
                  <h4 class="card-title">
                    <a href="#">Black & White Stripes</a>
                  </h4>
                  <h5>$24.99</h5>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
              <div class="card h-100">
                <div id="zoom">
                  <a href="#"><img class="card-img-top" src="images/700x400-collection-landscape.jpg" alt=""></a>
                </div>
                <div class="card-body">
                  <h4 class="card-title">
                    <a href="#">Collection Landscape</a>
                  </h4>
                  <h5>$24.99</h5>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

          </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
